=== AdSavvy Retargeting ===
Contributors: ramv
Tags: AdSavvy, retargeting, ads
Requires at least: 3.0
Tested up to: 3.4.1
Stable tag: 1.0
License: MIT

AdSavvy the predictive marketing platform for small and medium businesses. 

== Description ==

Plugin that enables any wordpress site to start remarketing on the AdSavvy platform

== Installation ==

* Upload the AdSavvy plugin to your blog
* Activate it
* Navigate to Settings -> AdSavvy Remarketing
* Enter your adsvy_org_id and adsvy_app_id from your AdSavvy (https://console.savvyads.com) account
* Your script is going to be embedded to your footer

== Changelog ==

= 1.0 = 
* First major version
